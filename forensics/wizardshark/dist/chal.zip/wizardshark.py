import socket
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.backends import default_backend
import os

def encrypt_message(message: str, secret_key: bytes) -> bytes:
    # Generate a random IV
    iv = os.urandom(16)
    
    # Pad the message
    padder = padding.PKCS7(algorithms.AES.block_size).padder()
    padded_message = padder.update(message.encode()) + padder.finalize()
    
    # Encrypt the message
    cipher = Cipher(algorithms.AES(secret_key), modes.CBC(iv), backend=default_backend())
    encryptor = cipher.encryptor()
    ciphertext = encryptor.update(padded_message) + encryptor.finalize()
    
    # Return IV + Ciphertext
    return iv + ciphertext

# Define UDP parameters
server_ip = '192.168.0.22'  # Localhost for example
server_port = 80      # Port to send data to

# Create a UDP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

# Example usage
secret_key = os.urandom(32)  # 32 bytes for AES-256
message = "Heres your flag ;)"
encrypted_message = encrypt_message(message, secret_key)

# Send the encrypted message
sock.sendto(encrypted_message, (server_ip, server_port))

# Print the secret key in hex format
print(f"Secret key (hex): {secret_key.hex()}")

# Close the socket
sock.close()

